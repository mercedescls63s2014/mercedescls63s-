# CLS 63 S Drive - Android project
1. Create a new GitHub repository and upload everything in this folder (keep the .github folder).
2. Open the Actions tab -> "Build APK" -> wait ~4 minutes.
3. Download the artifact "CLS63S-APK", unzip it, and install app-debug.apk on your phone.
(Or open in Android Studio after running scripts/fetch-libs.sh, then Build > Build APK.)
