#!/usr/bin/env bash
# Bundles three.js locally so the game works fully offline inside the APK
set -e
cd "$(dirname "$0")/.."
W=app/src/main/assets/www/lib
mkdir -p $W/jsm/loaders $W/jsm/utils /tmp/t
(cd /tmp/t && npm pack three@0.160.0 >/dev/null && tar xzf three-0.160.0.tgz)
cp /tmp/t/package/build/three.module.js $W/
cp /tmp/t/package/examples/jsm/loaders/GLTFLoader.js $W/jsm/loaders/
cp /tmp/t/package/examples/jsm/utils/BufferGeometryUtils.js $W/jsm/utils/
echo "three.js bundled."
